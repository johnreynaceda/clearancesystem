<div>
    <div>
        <?php echo e($this->table); ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\OTHER PROJECTS\ClearanceSystem\resources\views/livewire/admin/clearance/clearance-list.blade.php ENDPATH**/ ?>