@section('title', 'Grade Level')
<x-admin-layout>
    <livewire:admin.grade-level.grade-level-list/>
</x-admin-layout>