@section('title', 'Manage Student')
<x-adviser-layout>
   <livewire:adviser.student.manage-student/>
</x-adviser-layout>