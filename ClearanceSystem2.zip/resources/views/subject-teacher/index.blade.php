@section('title', 'Manage Clearance')
<x-subject-teacher-layout>
    sdsdsd
</x-subject-teacher-layout>