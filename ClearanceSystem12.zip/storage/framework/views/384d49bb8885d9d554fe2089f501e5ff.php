<?php $__env->startSection('title', 'Dashboard'); ?>
<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <dl class="mx-auto grid grid-cols-1 gap-px bg-gray-900/5 sm:grid-cols-2 lg:grid-cols-4">
  <div class="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-2 bg-white px-4 py-10 sm:px-6 xl:px-8">
    <dt class="text-sm font-bold leading-6 text-gray-700">TOTAL STUDENTS</dt>
    <dd class="w-full flex-none text-3xl font-medium leading-10 tracking-tight text-gray-900"><?php echo e(\App\Models\Student::count()); ?></dd>
  </div>
  <div class="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-2 bg-white px-4 py-10 sm:px-6 xl:px-8">
       <dt class="text-sm font-bold leading-6 text-gray-700">TOTAL ADVISERS</dt>
    <dd class="w-full flex-none text-3xl font-medium leading-10 tracking-tight text-gray-900"><?php echo e(\App\Models\TeacherDesignation::whereNull('subject_id')->count()); ?></dd>
  </div>
  <div class="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-2 bg-white px-4 py-10 sm:px-6 xl:px-8">
      <dt class="text-sm font-bold leading-6 text-gray-700">TOTAL SUBJECT TEACHERS</dt>
    <dd class="w-full flex-none text-3xl font-medium leading-10 tracking-tight text-gray-900"><?php echo e(\App\Models\TeacherDesignation::whereNull('strand_id')->count()); ?></dd>
  </div>
  <div class="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-2 bg-white px-4 py-10 sm:px-6 xl:px-8">
     <dt class="text-sm font-bold leading-6 text-gray-700">TOTAL USERS</dt>
    <dd class="w-full flex-none text-3xl font-medium leading-10 tracking-tight text-gray-900"><?php echo e(\App\Models\User::count()); ?></dd>
  </div>
</dl>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\OTHER PROJECTS\ClearanceSystem\resources\views/admin/index.blade.php ENDPATH**/ ?>