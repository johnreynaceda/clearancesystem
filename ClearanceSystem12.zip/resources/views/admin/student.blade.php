@section('title', 'Students')
<x-admin-layout>
    <livewire:admin.student.student-list/>
</x-admin-layout>