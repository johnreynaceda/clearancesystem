@section('title', 'Clearance')
<x-student-layout>
    <livewire:student.student-clearance/>
</x-student-layout>