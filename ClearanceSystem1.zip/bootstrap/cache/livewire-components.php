<?php return array (
  'admin.clearance.clearance-list' => 'App\\Http\\Livewire\\Admin\\Clearance\\ClearanceList',
  'admin.grade-level.grade-level-list' => 'App\\Http\\Livewire\\Admin\\GradeLevel\\GradeLevelList',
  'admin.strand.strand-list' => 'App\\Http\\Livewire\\Admin\\Strand\\StrandList',
  'admin.student.student-list' => 'App\\Http\\Livewire\\Admin\\Student\\StudentList',
  'admin.subject.subject-list' => 'App\\Http\\Livewire\\Admin\\Subject\\SubjectList',
  'admin.teacher.teacher-list' => 'App\\Http\\Livewire\\Admin\\Teacher\\TeacherList',
  'admin.user.user-list' => 'App\\Http\\Livewire\\Admin\\User\\UserList',
  'adviser.adviser-clearance' => 'App\\Http\\Livewire\\Adviser\\AdviserClearance',
  'adviser.manage-clearance' => 'App\\Http\\Livewire\\Adviser\\ManageClearance',
  'adviser.student.manage-student' => 'App\\Http\\Livewire\\Adviser\\Student\\ManageStudent',
  'student.student-clearance' => 'App\\Http\\Livewire\\Student\\StudentClearance',
);