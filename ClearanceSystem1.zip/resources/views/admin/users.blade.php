@section('title', 'Users')
<x-admin-layout>
    <livewire:admin.user.user-list/>
</x-admin-layout>