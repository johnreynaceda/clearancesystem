<div>
    {{$this->table}}
</div>
