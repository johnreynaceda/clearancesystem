<svg class="h-3 w-3 text-danger-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
  <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd"/>
</svg><?php /**PATH C:\xampp\htdocs\OTHER PROJECTS\ClearanceSystem\storage\framework\views/80dcddef539ab37f25c3583d9bfc13ec.blade.php ENDPATH**/ ?>