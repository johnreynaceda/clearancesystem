<div>
    <?php echo e($this->table); ?>

</div>
<?php /**PATH C:\xampp\htdocs\OTHER PROJECTS\ClearanceSystem\resources\views/livewire/admin/subject/subject-list.blade.php ENDPATH**/ ?>