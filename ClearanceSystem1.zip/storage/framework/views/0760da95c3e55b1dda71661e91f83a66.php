<div>
   <div>
    <?php echo e($this->table); ?>

   </div>
</div>
<?php /**PATH C:\xampp\htdocs\OTHER PROJECTS\ClearanceSystem\resources\views/livewire/admin/strand/strand-list.blade.php ENDPATH**/ ?>