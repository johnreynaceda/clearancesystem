<div>
   <div>
    <?php echo e($this->table); ?>

   </div>
</div>
<?php /**PATH C:\xampp\htdocs\OTHER PROJECTS\ClearanceSystem\resources\views/livewire/admin/grade-level/grade-level-list.blade.php ENDPATH**/ ?>