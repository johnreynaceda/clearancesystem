<div>
  <div>
    <?php echo e($this->table); ?>

  </div>
</div>
<?php /**PATH C:\xampp\htdocs\OTHER PROJECTS\ClearanceSystem\resources\views/livewire/adviser/adviser-clearance.blade.php ENDPATH**/ ?>