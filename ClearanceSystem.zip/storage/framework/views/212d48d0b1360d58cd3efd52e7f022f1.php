<div x-data>
  <div><?php echo e($this->form); ?></div>
  <div class="mt-5 border-t py-5 px-2">
    <div>
      <div x-ref="printContainer">
        <header class="flex space-x-2 items-end">
          <img src="<?php echo e(asset('images/logo.png')); ?>" class="h-20" alt="">
          <div>
            <h1 class="font-bold text-xl">CARMEN NATIONAL HIGH SCHOOL</h1>
            <h1 class="text-sm">ONLINE CLEARANCE PROCESSING SYSTEM</h1>
          </div>
        </header>
        <?php if($report == 'Students'): ?>
          <div class="mt-8">
            <h1 class="font-bold text-xl text-center">STUDENT REPORTS</h1>
          </div>
          <div class="mt-8">
            <p class="mb-1">List below are the students who cleared their clearance.</p>
            <table id="example" class="table-auto " style="width:100%">
              <thead class="font-normal">
                <tr>

                  <th class="border text-left px-2 text-sm font-BOLD text-gray-600 py-2">STUDENT FULLNAME</th>
                  <th class="border text-left px-2 text-sm font-BOLD text-gray-600 py-2">STRAND
                  </th>
                  <th class="border text-left px-2 text-sm font-BOLD text-gray-600 py-2">STATUS
                  </th>

                </tr>
              </thead>
              <tbody class="">

                <?php $__currentLoopData = \App\Models\StudentSubmittion::where('status', 2)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="border text-gray-600  px-3 py-1">
                      <?php echo e($item->student->firstname . ' ' . $item->student->lastname); ?></td>
                    <td class="border text-gray-600  px-3 py-1"><?php echo e($item->student->strand->name); ?> -
                      <?php echo e($item->student->gradeLevel->name); ?> </td>
                    </td>
                    <td class="border text-gray-600  px-3 py-1">Cleared
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </tbody>
            </table>
          </div>
        <?php elseif($report == 'Advisers'): ?>
            <div class="mt-8">
            <h1 class="font-bold text-xl text-center">ADVISERS REPORTS</h1>
          </div>
          <div class="mt-8">
            <p class="mb-1">List below are the Advisers</p>
            <table id="example" class="table-auto " style="width:100%">
              <thead class="font-normal">
                <tr>

                  <th class="border text-left px-2 text-sm font-BOLD text-gray-600 py-2">ADVISER FULLNAME</th>
                  <th class="border text-left px-2 text-sm font-BOLD text-gray-600 py-2">STRAND
                  </th>
               

                </tr>
              </thead>
              <tbody class="">

                <?php $__currentLoopData = \App\Models\TeacherDesignation::where('strand_id', '!=', null)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="border text-gray-600  px-3 py-1">
                      <?php echo e($item->teacher->firstname . ' ' . $item->teacher->lastname); ?></td>
                    <td class="border text-gray-600  px-3 py-1"><?php echo e($item->strand->name); ?></td>
                    </td>
                   
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </tbody>
            </table>
          </div>
        <?php elseif($report == 'Subject Teacher'): ?>
            <div class="mt-8">
            <h1 class="font-bold text-xl text-center">SUBJECT TEACHER REPORTS</h1>
          </div>
          <div class="mt-8">
            <p class="mb-1">List below are the Subject Teacher</p>
            <table id="example" class="table-auto " style="width:100%">
              <thead class="font-normal">
                <tr>

                  <th class="border text-left px-2 text-sm font-BOLD text-gray-600 py-2">SUBJECT TEACHER FULLNAME</th>
                  <th class="border text-left px-2 text-sm font-BOLD text-gray-600 py-2">SUBJECT
                  </th>
               

                </tr>
              </thead>
              <tbody class="">

                <?php $__currentLoopData = \App\Models\TeacherDesignation::where('subject_id', '!=', null)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="border text-gray-600  px-3 py-1">
                      <?php echo e($item->teacher->firstname . ' ' . $item->teacher->lastname); ?></td>
                    <td class="border text-gray-600  px-3 py-1"><?php echo e($item->subject->name); ?></td>
                    </td>
                   
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </tbody>
            </table>
          </div>
        <?php else: ?>
        <?php endif; ?>
      </div>
    </div>

    <div class="mt-5 flex justify-end">
      <?php if($report): ?>
          <button class="bg-gray-600  text-white font-bold py-2 px-4 rounded"
        @click="printOut($refs.printContainer.outerHTML);">
        Print
      </button>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\OTHER PROJECTS\ClearanceSystem\resources\views/livewire/admin/report.blade.php ENDPATH**/ ?>