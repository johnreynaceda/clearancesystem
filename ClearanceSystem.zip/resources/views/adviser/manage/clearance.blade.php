@section('title', request('name'))
<x-adviser-layout>
    <livewire:adviser.manage-clearance/>
</x-adviser-layout>