@section('title', 'Clearance')
<x-admin-layout>
    <livewire:admin.clearance.clearance-list/>
</x-admin-layout>