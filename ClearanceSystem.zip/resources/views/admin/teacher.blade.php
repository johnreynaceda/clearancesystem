@section('title', 'Teacher')
<x-admin-layout>
   <livewire:admin.teacher.teacher-list/>
</x-admin-layout>