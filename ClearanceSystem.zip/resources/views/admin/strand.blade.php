@section('title', 'Strand')
<x-admin-layout>
    <livewire:admin.strand.strand-list/>
</x-admin-layout>