@section('title', 'Subjects')
<x-admin-layout>
    <livewire:admin.subject.subject-list/>
</x-admin-layout>